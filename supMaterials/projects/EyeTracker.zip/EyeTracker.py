#Name - EyeTracker.py
#Purpose - Eye Tracking project: Create point shapefile from eyetracking csv data and add to map 
#Date - 01/11/2013
#Author - Rahul Ashok Bhosle
#input:  <workspace> <.mxd filename> <.csv filename>
#The Extents.txt file must be in your working directory

import arcpy, csv, os, sys

sys.path.append(sys.argv[0])

#Lines 9 to 14: Opens an existing map document and gets the extent of its data frame. 
#Default Map Document:WorldMapOceanLayer.mxd
arcpy.env.overwriteOutput = 1
arcpy.env.workspace = sys.argv[1]
MapDocument = sys.argv[1] + "\\" + sys.argv[2]

#Reading the eye tracking data in the .csv format
#Default .csv file: ETdata.csv
EyeTrack = sys.argv[1] + "\\" + sys.argv[3]
ifile = open(EyeTrack, "rb")
reader = csv.reader(ifile, delimiter=",")

rownum = 0
FPOGX = []
FPOGY = []

for row in reader:
    if rownum == 0 or rownum ==2:
        junk = row
    elif rownum == 1:
        ResX = float(row[3])
        ResY = float(row[4])
    else:
        #if row[8] == "1":
        FPOGX.append(row[3])
        FPOGY.append(row[4])
    rownum += 1

#The Extents.txt file contains the min and max X and Y screen pixel values
#for the map as displayed on the screen when the eye tracking data was
#generated
file = os.path.dirname(sys.argv[0]) + "\\Extents.txt"
EObject = open(file,'r')

EStrings = EObject.readlines()
EStrings = [float(x) for x in EStrings]

#The extent of the data frame in terms of pixels
#could hard code this instead of reading
#from the file  
#The min and max  X and Y geographic extent values
#are also included in the file although
#these can be determined directly from the map
#document          
MinXP = EStrings[0]
MaxXP = EStrings[1]
MinYP = ResY - EStrings[3]
MaxYP = ResY - EStrings[2]

#Geographic extent of map
Xmin = EStrings[4]
Xmax = EStrings[5]
Ymin = EStrings[6]
Ymax = EStrings[7]

#Geographic extent can also be set this way

#mxd = arcpy.mapping.MapDocument(MapDocument)
#dfs = arcpy.mapping.ListDataFrames(mxd)
#df = dfs[0]
#Xmin = df.extent.XMin
#Ymin = df.extent.YMin
#Xmax = df.extent.XMax 
#Ymax = df.extent.YMax

#Converting from string to float    
FPOGX = [float(x) for x in FPOGX]
FPOGY = [float(y) for y in FPOGY]

#Close the .csv file
ifile.close()


FPOGXINV = [x for x in FPOGX]
FPOGYINV = [1.00 - y for y in FPOGY]

#FPGOXP and FPOGYP are the conversion of the eye track coordinates into their pixel values.
FPOGXP = [ x*ResX for x in FPOGXINV]
FPOGYP = [ y*ResY for y in FPOGYINV]

#GDiffX and Y are the dx and dy in terms of the coordinate system.
GDiffX = Xmax - Xmin
GDiffY = Ymax - Ymin

#PDiffX and Y are the dx and dy in terms of Pixels.
PDiffX = MaxXP - MinXP
PDiffY = MaxYP - MinYP


#FPOGXG and YG are the eye tracking points represented in the map document's coordinate system
FPOGXG = [(Xmin + ((x-MinXP)*GDiffX/PDiffX)) for x in FPOGXP]
FPOGYG = [(Ymin + ((y-MinYP)*GDiffY/PDiffY)) for y in FPOGYP]

#ETPList is the eye tracking which we created above
ETPList = [[FPOGXG[i],FPOGYG[i]] for i in range(len(FPOGXG))]


# Create an empty Point object
ETpoint = arcpy.Point()

# A list to hold the PointGeometry objects
ETpointGeometryList = []

# For each coordinate pair, populate the Point object and create a new PointGeometry
for pt in ETPList:
    ETpoint.X = pt[0]
    ETpoint.Y = pt[1]

    ETpointGeometry = arcpy.PointGeometry(ETpoint)
    ETpointGeometryList.append(ETpointGeometry)

# Create a copy of the PointGeometry objects, by using pointGeometryList
#  as input to the CopyFeatures tool.
#
mxd1 = arcpy.mapping.MapDocument(MapDocument)
dfs1 = arcpy.mapping.ListDataFrames(mxd1)
df1 = dfs1[0]

ETinFeature = os.path.dirname(sys.argv[0]) + "\\ETdata.shp"
ETinFeatureLayer = os.path.dirname(sys.argv[0]) + "\\ETDataLayer"
ETactualLayer = os.path.dirname(sys.argv[0]) + "\\ETLayer.lyr"

arcpy.CopyFeatures_management(ETpointGeometryList, ETinFeature)    
arcpy.DefineProjection_management(ETinFeature, df1.spatialReference)
arcpy.MakeFeatureLayer_management(ETinFeature, ETinFeatureLayer)
arcpy.SaveToLayerFile_management(ETinFeatureLayer, ETactualLayer)


ETaddLayer = arcpy.mapping.Layer(ETactualLayer)
arcpy.mapping.AddLayer(df1, ETaddLayer)

#Saving a copy of the stuff done and having it open
ETcopyName = os.path.dirname(sys.argv[0]) + "\\EyeTracker.mxd"
if arcpy.Exists(ETcopyName):
    arcpy.Delete_management(ETcopyName)
mxd1.saveACopy(ETcopyName)
del df1
del mxd1
os.startfile(ETcopyName)


