# ---------------------------------------------------------------------------
#Title: zipAll.py
#
#Description: zips all files in the input directory
#
#Author: Rodan
#
#Date Written: 02/22/09
# -----------------------------------------------------------------------------


import zipfile, os

#set input directory
inDir = "c:/gispy/scratch/monsterIsland/godzilla"

#get list of files in inDir
fileList = os.listdir(inDir)

#set name for zipfile as name of directory being zipped
outZipName = os.path.basename(inDir) + ".zip"

#create zip file
tFile = zipfile.ZipFile(inDir + "/" + outZipName, 'w')

#write directory contents to the zip file
for file in fileList:
    tFile.write(inDir + "/" + file, file, zipfile.ZIP_DEFLATED)

#close zipfile
tFile.close()

