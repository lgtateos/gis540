#ShapeToPoints.py
#
#Author
#  Dan Patterson
#  Dept of Geography and Environmental Studies
#  Carleton University, Ottawa, Canada
#  Dan_Patterson@carleton.ca
#
#Date       June 16 2005
#Modified   Dec 2007, Apr 2008
#
#History  A variety of example scripts have contributed to the final form.
#
#Purpose
#  Convert a point, multipoint, polyline or polygon layer to a unique point
#  shapefile or CSV file which contains X, Y values and Z/M if present.  
#  Multiparts are exploded.
#
#Data menu option.
#
#Properties (right-click on the tool and specify the following)
#General
#  Name   ShapeToPoints
#  Label  Shape to Points
#  Desc   Produces a shapefile or csv file which contains unique points.
#         Selections will be honored in the output if you desire
#         a subset.
#
#Source script UniquePnts.py
#
#Parameter list
#                                Parameter Properties
#           Display Name         Data type        Type      Direction  MultiValue  Dependency
#  argv[1]  Feat. layer to conv. Feature Layer     Required  Input      No
#  argv[2]  Unique Points?       Boolean           Required  Input      No
#  argv[3]  Output text file     Text file         Optional  Output     No
#  argv[4]  Optional fields      Field             Optional  Input      Yes        argv[1]
#  argv[5]  Output shapefile     Feature class     Optional  Output     No

#--------------------------------------------------------------------
def pntXY(pnt):
  #Gets X,Y coordinates given a point object
  #  Returns a string
  XY= str(pnt.X) + ", " + str(pnt.Y)
  return XY
#--------------------------------------------------------------------
def pntAllXYZM(theType, pnts, shapeList, isZ, isM):
  #requires the shape type, shapeList is OID and a shape and Z/M boolean
  #returns:
  #  list of lists of all points, including X,Y and Z/M values
  #  ([OIDval, PntNum, X, Y, Z, M])
  #  simply decide which ones you need upon retrieval
  #
  # the isZ and isM can be determined from the feature class (inFC)
  # using a describe on the input feature layer...
  # desc=gp.Describe
  # fc = desc(inFC).CatalogPath.replace("\\","/")
  # isZ = desc(inFC).hasZ
  # isM = desc(inFC).hasM
  lineList = []
  OIDval = shapeList[0]    #object ID
  aShape = shapeList[1]    #the shape
  aCount = shapeList[2]    #shape counter
  #for aNum in range(0,len(shapeList[0][1])):
  i = 0; PntNum = 0
  if (theType == "Point"):        #points
    pnt = aShape.GetPart()
    X = pnt.X; Y = pnt.Y
    XY = pntXY(pnt)
    aList = listAppendZM(aCount, OIDval, PntNum, X, Y, isZ, isM, pnt)
    lineList.append(aList)
    PntNum = PntNum + 1
    aCount=aCount+1
  elif theType == "Multipoint":   #multipoint
    aPart = 0
    while aPart < aShape.PartCount:
      pnt = aShape.GetPart(aPart)
      X = pnt.X; Y = pnt.Y
      XY = pntXY(pnt)
      aList = listAppendZM(aCount, OIDval, PntNum, X, Y, isZ, isM, pnt)
      lineList.append(aList)
      aCount = aCount + 1
      PntNum = PntNum + 1
      aPart = aPart + 1
  else:  #polyline or polygon
    aPart = 0
    while aPart < aShape.PartCount:
      anArray = aShape.GetPart(aPart)
      anArray.Reset()
      pnt=anArray.Next()
      j = 0
      while pnt:
        X = pnt.X; Y = pnt.Y
        XY = pntXY(pnt)
        aList =listAppendZM(aCount, OIDval, PntNum, X, Y, isZ, isM, pnt)
        lineList.append(aList)
        #gp.AddMessage(str(aList))
        aCount = aCount + 1
        PntNum = PntNum + 1
        pnt = anArray.Next()
        if not pnt:
          pnt = anArray.Next()
      aPart = aPart + 1
  return lineList
#-------------------------------------------------------------
def pntUniqueXYZM(theType, pnts, shapeList, isZ, isM):
  #requires the shape type, shapeList is OID and a shape and Z/M boolean
  #returns:
  #  list of lists of unique points, including X,Y and Z/M values
  #  ([OIDval, PntNum, X, Y, Z, M])
  #  simply decide which ones you need upon retrieval
  #
  # the isZ and isM can be determined from the feature class (inFC)
  # using a describe on the input feature layer...
  # desc=gp.Describe
  # fc = desc(inFC).CatalogPath.replace("\\","/")
  # isZ = desc(inFC).hasZ
  # isM = desc(inFC).hasM
  if theType == "Polyline":
    m = 1
  elif theType == "Polygon":
    m = 2
  lineList = []
  i = 0; PntNum = 0
  OIDval = shapeList[0]    #object ID
  aShape = shapeList[1]    #the shape
  aCount = shapeList[2]    #shape counter
  if (theType == "Point"):        #points
    pnt = aShape.GetPart()
    X = pnt.X; Y = pnt.Y
    XY = pntXY(pnt)
    if XY not in pnts:
      pnts.append(XY)
      aList = listAppendZM(aCount, OIDval, PntNum, X, Y, isZ, isM, pnt)
      lineList.append(aList)
    aCount=aCount+1
  elif theType == "Multipoint":   #multipoint
    aPart = 0
    while aPart < aShape.PartCount:
      pnt = aShape.GetPart(aPart)
      X = pnt.X; Y = pnt.Y
      XY = pntXY(pnt)
      if XY not in pnts:
        pnts.append(XY)
        aList = listAppendZM(aCount, OIDval, PntNum, X, Y, isZ, isM, pnt)
        lineList.append(aList)
        PntNum = PntNum + 1
        aPart = aPart + 1
  else:  #polyline or polygon
    aPart = 0
    while aPart < aShape.PartCount:
      anArray = aShape.GetPart(aPart)
      numVertices = anArray.count
      anArray.Reset()
      pnt=anArray.Next()
      j = 0
      while j < (numVertices - m) :
        pnt = anArray.GetObject(j)
        X = pnt.X; Y = pnt.Y
        XY = pntXY(pnt)
        if XY not in pnts:
          pnts.append(XY)
          aList =listAppendZM(aCount, OIDval, PntNum, X, Y, isZ, isM, pnt)
          lineList.append(aList)
          aCount = aCount + 1
          PntNum = PntNum + 1
        pnt = anArray.GetObject(j + 1)
        if not pnt:
          j = j + 1
        else:
          XY = pntXY(pnt)
          X = pnt.X; Y = pnt.Y
          if XY not in pnts:
            pnts.append(XY)
            aList = listAppendZM(aCount, OIDval, PntNum, X, Y, isZ, isM, pnt)
            #gp.AddMessage(str(aList))
            lineList.append(aList)
            aCount = aCount + 1
            PntNum = PntNum + 1
        j = j + 1
      aPart = aPart + 1
  return lineList
#-------------------------------------------------------------
def listAppendZM(aCount, OIDval, PntNum, X, Y, isZ, isM, pnt):
  #appends ZM values to a list if they exists
  if isZ:
    aList = [aCount, OIDval, PntNum, X, Y, pnt.Z]
  elif isM:
    aList = [aCount, OIDval, PntNum, X, Y, pnt.M]
  else:
    aList = [aCount, OIDval, PntNum, X, Y]
  return aList
#-------------------------------------------------------------
#Main portion
#Import the standard modules, create the geoprocessor
import os, sys, string
try:     #for 9.0/9.1 or win32com users
  import win32com.client
  gp = win32com.client.Dispatch("esriGeoprocessing.GpDispatch.1")
except:  #for 9.2
  import arcgisscripting
  gp = arcgisscripting.create()
try:
  gp.AddToolbox("C:/Program Files/ArcGIS/ArcToolbox/Toolboxes/Data Management Tools.tbx")
except:
  gp.AddMessage("Toolbox does not reside in the required path...edit the script" + "\n" +
                "C:/Program Files/ArcGIS/ArcToolbox/Toolboxes/Data Management Tools.tbx")
  sys.exit()
#
#Get the input feature class, optional fields and the output filename
inFC = sys.argv[1]
desc=gp.Describe
doUnique = sys.argv[2]
outCSVfile = sys.argv[3]
theFields = sys.argv[4]
outFC = sys.argv[5]
#
#Check to see if there is an output being created
if outCSVfile == "#" and outFC == "#":
  gp.AddMessage("\n" + "An output CSV and/or SHP file is needed. Exiting..." + "\n")
  sys.exit()
#
#Get the spatial reference
fc = desc(inFC).CatalogPath.replace("\\","/")
SR = gp.CreateSpatialReference_management("#",fc,"#","#","#","#")
#
#check the shape type and figure out which field is the
#  geometry/shape field and whether it is z or m enabled
theType = desc(inFC).ShapeType
shapeField = desc(inFC).ShapeFieldName
OIDField = desc(inFC).OIDFieldName
isZ = desc(inFC).hasZ
isM = desc(inFC).hasM
#
#Create the header and get the format
if (theType == "Point") or (theType == "Multipoint"):
  aHeader = "ID, OrigID, PntNum, X, Y"
  fieldFormat = [["i",9,0], ["i",9,0], ["i",9,0], ["f",16,9], ["f",16,9]]
else:
  aHeader = "ID, OrigID, PntNum, X, Y"
  fieldFormat = [["i",9,0], ["i",9,0], ["i",9,0], ["f",16,9], ["f",16,9]]
if isZ:
  aHeader = aHeader + ", Z"
  fieldFormat = [["i",9,0], ["i",9,0], ["i",9,0], ["f",16,9], ["f",16,9], ["f",16,9]]
elif isM:
  aHeader = aHeader + ", M"
  fieldFormat = [["i",9,0], ["i",9,0], ["i",9,0], ["f",16,9], ["f",16,9], ["f",16,9]]
#
gp.AddMessage("\n" + "Processing: " + str(fc) + "\n" +
              "Type: " + theType + "\n" +
              "Is Z? " + str(isZ ) + "\n" +
              "Is M? " + str(isM) + "\n" +
              "All points? " + str(doUnique))
#
#Create a cursor on the feature class
#  Cycle through the shapes, which may be a single or multipart
#  and in the case of polygons, may contain donuts.
shapeList = []
rows = gp.SearchCursor(inFC)
#rows.reset()
row = next(rows)
outData = []
pnts = []
#
#produce a list of fields for point files
if theType == "Point" and theFields != "#" and outCSVfile != "#":
  fieldNames = theFields.split(";")
  gp.AddMessage("Adding field information for: " + str(fieldNames))
  for aField in fieldNames:
    aHeader = aHeader + ", " + aField
#
aCount = 0 #main shape counter
while row:                        #cycle through the shapes
  OIDval = row.GetValue(OIDField)
  aShape = row.shape
  shapeList = [OIDval, aShape, aCount]
  if doUnique == "true":
    theReturned = pntUniqueXYZM(theType, pnts, shapeList, isZ, isM)
  else:
    theReturned = pntAllXYZM(theType, pnts, shapeList, isZ, isM)
    #if theReturned != []:
  if theType == "Point" and theFields != "#" and outCSVfile != "#":
    aLine = []
    for aField in fieldNames:
      #aLine.append(row.GetValue(aField)) #+ ", "
      theReturned[0].append(row.GetValue(aField))
  aCount = aCount + 1
  outData = outData + theReturned
  #gp.AddMessage("outData " + str(outData))
  row = next(rows)                # Get the next feature and repeat
#
#Create the optional CSV file for output
if outCSVfile != "#":
  gp.AddMessage("\n" + "CSV file created: " + outCSVfile)
  csvFile = open(outCSVfile,'w')
  csvFile.write(aHeader)
  for i in outData:
    aLine = ""
    aSep = ""
    for j in i:
      aLine = aLine + aSep + str(j)
      aSep = ", "
    csvFile.write("\n" + aLine)
  csvFile.flush()
  csvFile.close()
#
#Create the optional shapefile, add the base fields and the required fields
if outFC != "#":
  fullName = os.path.split(outFC)
  outFolder = fullName[0]
  outFName =  fullName[1].replace(" ", "_")
  outType = "Point"
  try:
    gp.CreateFeatureclass_management(outFolder, outFName, outType, "#", "Disabled", "Disabled", SR)
    gp.AddMessage("\n" + "Shapefile created: " + str(outFC) + "\n")
  except:
    gp.AddMessage("\n" + "Create feature class failed" + gp.GetMessages())
    sys.exit()
  #
  theFieldNames=string.split(aHeader,",")
  for i in range(0, len(fieldFormat)):
    fType = fieldFormat[i][0]
    w = fieldFormat[i][1]
    d = fieldFormat[i][2]
    fName = string.strip(theFieldNames[i])
    if fType == "i":
      try:
        gp.AddField_management(outFC, fName, "long", w, d)
      except:
        gp.AddMessage("Field exists " + fName)
    elif fType == "f":
      gp.AddField_management(outFC, fName, "double", w, d)
  #
  try:
    cur = gp.InsertCursor(outFC)
    aPnt = gp.CreateObject('point')
  except:
    gp.AddMessage("Failed to create cursor")
    sys.exit()
  if (theType == "Point") or (theType == "Multipoint"):
    m=2 #m=1  edited
  else:
    m=2
  aCount=0
  #gp.AddMessage("final outdata: " + "\n" + str(outData))
  for i in range(0,len(outData)):    
    aList = outData[i]
    #gp.AddMessage("aList " + str(aList))
    aPart = 0
    try:
      aPnt.id = aList[0]
      aPnt.x = float(str(aList[m+1]))
      aPnt.y = float(str(aList[m+2]))
      feat = cur.NewRow()
      feat.shape = aPnt
      feat.SetValue("ID", aCount)
      feat.SetValue("OrigID", aList[1])
      feat.SetValue("PntNum", aList[2])  #here
      feat.SetValue("X", aList[m+1])
      feat.SetValue("Y", aList[m+2])
      if isZ:
        feat.SetValue("Z", aList[m+3])
      elif isM:
        feat.SetValue("M", aList[m+3])
      cur.InsertRow(feat)
      aCount = aCount + 1
      aPart = aPart + 1
    except:
      gp.AddMessage("cannot create feature" + gp.GetMessages())
#
#clean up and exit
try:
  del outData
  gp.AddMessage("\n" + "Processing complete" + "\n")
  del gp
except:
  gp.AddMessage("\n" + "Processing complete" + "\n")
  
